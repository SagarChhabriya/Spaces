def greet():
    print("RADHE RADHE 🙏🏼")